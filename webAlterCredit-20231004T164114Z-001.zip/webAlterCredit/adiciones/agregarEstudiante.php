<?php
include("../modelo/mEstudiante.php");
$codigo=$_POST['codigo'];
$nombre=$_POST['nombre'];
$edad=$_POST['edad'];
$obj = new mEstudiante();
$agregado=$obj->agregarEstudiante($codigo,$nombre,$edad);
echo $agregado;
 ?>