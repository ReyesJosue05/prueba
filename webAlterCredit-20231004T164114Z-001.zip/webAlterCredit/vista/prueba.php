<?php 
$edad=7;
for($fila=0; $fila<$edad;$fila++){
for($col=1; $col<$edad;$col++)
echo "*";
echo "*".'<br>';
}
?>